const bodyParser = require("body-parser");
const cors = require("cors");
const express = require("express");
const session = require('express-session');
const cookieParser = require("cookie-parser");
const app = express();
require("dotenv").config();
const initRoutes = require("./routes");
const apiLogger = require('./utils/logger');
const { handleError, convertToApiError } = require('./utils/apiError')
const passport = require('passport');
const config = require('./config/config');
require('./config/passport');
const { bulkData, vaData } = require('./utils/Extract')
const { upload } = require('./utils/upload')

const fs = require('fs')
const path = require('path')
const multer = require('./utils/upload')
const awss3 = require("./utils/awss3upload");

app.use(cookieParser())
app.use(session(config.session));
app.use(passport.initialize());
app.use(passport.session());
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

app.disable("x-powered-by");

app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', req.header('origin'));
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    res.header('Access-Control-Allow-Credentials', 'true');

    if (req.method == 'OPTIONS') {
        res.header('Access-Control-Allow-Methods', 'PUT, POST, PATCH, DELETE, GET');
        return res.status(200).json({});
    }

    next();
});

app.use(
  cors(
    {
      origin: process.env.NODE_ENV !== "production"? [`http://localhost:3000`,`http://localhost:3010`,`http://172.25.121.70:3010`] : [`https://${process.env.CLIENT_URL}`,`https://${process.env.CLIENT_URL1}`],
      credentials: true, 
    }
  )
);
  
app.post('/test-extract', upload.single('excel_file'), async (req, res, next) => {
  try {
    const type = req.body.type
    const file = req.file ? req.file.filename : null
    let resultData = []
    let resultMessage = null
    if(type === 'bulk'){
      const {excelData,message} = await bulkData(file,0)
      resultData = excelData
      resultMessage = message
    } else {
      const {excelData,message} = await vaData(file,0)
      resultData = excelData
      resultMessage = message
    }
    res.status(200).send({data:resultData,message:resultMessage});  
  } catch(error) {
    console.log(error);
    next(error)
  }
});

initRoutes(app);

app.use(convertToApiError);
app.use((err, req, res, next) => {
  handleError(err, res)
})

const port = process.env.PORT || 443;
app.listen(port, () => {
  apiLogger('info', `Server is running on port ${port}`)
  console.log(`Server apical-mpu has started on the port ${port}`);
});